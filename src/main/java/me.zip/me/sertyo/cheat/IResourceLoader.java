package me.sertyo.cheat;

import java.io.IOException;

public interface IResourceLoader {
    byte[] loadTexture() throws IOException;
}

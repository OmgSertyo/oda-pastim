package me.sertyo.api.profile;

import me.sertyo.j2c.Native;

@Native
public enum CheatRole {
    NULL,
    VISITOR,
    USER,
    TESTER,
    ADMIN,
    DEVELOPER
}
